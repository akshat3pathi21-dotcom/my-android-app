package com.riya.companion;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.speech.RecognizerIntent;
import android.content.Intent;
import java.util.Locale;
import java.util.ArrayList;

public class MainActivity extends Activity {
    WebView web;
    TextToSpeech tts;
    static final int SPEECH_REQUEST = 101;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault()); });
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(this, "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @JavascriptInterface public void speak(String text) {
        runOnUiThread(() -> { if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "riya_reply"); });
    }
    @JavascriptInterface public void listen() {
        runOnUiThread(() -> {
            try {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Riya");
                startActivityForResult(i, SPEECH_REQUEST);
            } catch (Exception e) {
                web.evaluateJavascript("voiceResult('Voice recognition is unavailable on this phone.')", null);
            }
        });
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == SPEECH_REQUEST && result == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String escaped = r.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                web.evaluateJavascript("voiceResult('" + escaped + "')", null);
            }
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
