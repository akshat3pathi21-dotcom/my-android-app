# Riya Companion — Android source project

Starter project intended for Samsung Galaxy M31 running Android 12. It uses a native Android WebView shell, Android text-to-speech, and Android speech recognition intent. The chat replies are demo/local replies, not a live AI model. The video-call screen is a UI demo, not a real video call.

## Build requirements
- Android Studio / Android SDK (cloud build service may or may not accept this Gradle project ZIP).
- Android Gradle Plugin 8.2.2 and JDK 17.
- compileSdk 34; minSdk 23; targetSdk 32.

## Build
Open the project root in Android Studio and build the `app` debug APK. The output is typically `app/build/outputs/apk/debug/app-debug.apk`.

## To add real AI chat
Create a secure backend endpoint that holds your AI provider API key. Have the app send user messages to your backend over HTTPS. Do not embed provider API keys in the APK or commit them to source control.

## To add real video calling
Integrate a WebRTC SDK/service (for example, a hosted calling provider), configure a signaling server, issue short-lived call tokens from your backend, and request camera/microphone permissions at runtime. This project only provides a call-screen placeholder.

## Privacy
Speech recognition may use the phone's configured speech service and network. Ask for consent before sending conversation text to any AI backend. This app does not currently store chat history.
